import React from 'react'

const Message = () => {
  return (
    <div>You are not authorise</div>
  )
}

export default Message